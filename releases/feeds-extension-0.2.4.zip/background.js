(() => {
  // core/host.js
  var TOKEN_KEY = "xfs_token";
  var tokenKey = (id) => `${TOKEN_KEY}_${id}`;
  var METHODS = /* @__PURE__ */ new Set(["GET", "POST", "DELETE"]);
  var PATH_RE = /^\/api\/(feeds(\/[a-z0-9]{10}(\/items|\/verify(\/check)?)?)?|search|version)(\?[A-Za-z0-9=&._%-]*)?$/;
  var FEED_PATH = /^\/api\/feeds\/([a-z0-9]{10})(\/|\?|$)/;
  var FEED_ID = /^[a-z0-9]{10}$/;
  function createPrivilegedRequest(doFetch2, store2) {
    return async function request2(method, path, body, auth) {
      if (!METHODS.has(method) || typeof path !== "string" || !PATH_RE.test(path)) throw new Error("blocked request");
      const id = path.match(FEED_PATH)?.[1] || null;
      let token = null;
      let legacy = false;
      if (auth) {
        if (!id) throw new Error("blocked request");
        token = await store2.get(tokenKey(id));
        if (!token) {
          token = await store2.get(TOKEN_KEY);
          legacy = !!token;
        }
        if (!token) return { status: 401, data: { error: "no publish token on this browser" } };
      }
      const res = await doFetch2(method, path, body ?? null, token);
      const ok = res.status >= 200 && res.status < 300;
      if (method === "POST" && path === "/api/feeds" && res.data?.token) {
        if (res.status === 201 && FEED_ID.test(res.data.id)) await store2.set(tokenKey(res.data.id), res.data.token);
        const { token: _, ...rest } = res.data;
        return { status: res.status, data: rest };
      }
      if (method === "DELETE" && id && (ok || res.status === 404)) {
        await store2.set(tokenKey(id), null);
        if (legacy && ok) await store2.set(TOKEN_KEY, null);
      } else if (legacy && ok) {
        await store2.set(tokenKey(id), token);
        await store2.set(TOKEN_KEY, null);
      }
      return res;
    };
  }
  function guardedStore(store2) {
    const check = (k) => {
      if (typeof k !== "string" || k.startsWith(TOKEN_KEY)) throw new Error("blocked key");
    };
    const out = {
      get: async (k) => {
        check(k);
        return store2.get(k);
      },
      set: async (k, v) => {
        check(k);
        return store2.set(k, v);
      }
    };
    if (store2.watch) out.watch = (k, cb) => {
      check(k);
      return store2.watch(k, cb);
    };
    return out;
  }

  // extension/background.js
  var store = {
    get: async (k) => (await chrome.storage.local.get(k))[k] ?? null,
    set: (k, v) => chrome.storage.local.set({ [k]: v })
  };
  var settings = guardedStore(store);
  async function doFetch(method, path, body, token) {
    const headers = {};
    if (body) headers["Content-Type"] = "application/json";
    if (token) headers.Authorization = `Bearer ${token}`;
    const res = await fetch("https://gestaltschaft.com/feeds" + path, {
      method,
      headers,
      body: body ? JSON.stringify(body) : void 0,
      signal: AbortSignal.timeout(2e4)
    });
    let data = null;
    try {
      data = await res.json();
    } catch (_) {
    }
    return { status: res.status, data };
  }
  var request = createPrivilegedRequest(doFetch, store);
  async function handle(m) {
    if (m.op === "request") return request(m.method, m.path, m.body, !!m.auth);
    if (m.op === "get") return settings.get(m.key);
    if (m.op === "set") return settings.set(m.key, m.value);
    throw new Error("unknown op");
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id || !msg || typeof msg.op !== "string") return false;
    handle(msg).then((result) => sendResponse({ result }), (e) => sendResponse({ error: String(e?.message || e) }));
    return true;
  });
})();
