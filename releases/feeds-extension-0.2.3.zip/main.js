(() => {
  // core/safe.js
  var KINDS = ["foryou", "following"];
  var MAX_TEXT = 1e4;
  var MAX_BATCH = 100;
  var ID = /^\d{1,20}$/;
  var HANDLE = /^[A-Za-z0-9_]{1,15}$/;
  var MEDIA_HOST = /^https:\/\/(pbs|abs)\.twimg\.com\//;
  var MEDIA_TYPES = /* @__PURE__ */ new Set(["photo", "video", "animated_gif"]);
  var isId = (v) => typeof v === "string" && ID.test(v);
  var isHandle = (v) => typeof v === "string" && HANDLE.test(v);
  function str(v, max) {
    if (typeof v !== "string") return null;
    return v.replace(/[\u0000-\u0008\u000B-\u001F\u007F]/g, "").slice(0, max);
  }
  function safeMediaUrl(v) {
    if (typeof v !== "string" || v.length > 500 || !MEDIA_HOST.test(v)) return null;
    try {
      return new URL(v).href;
    } catch {
      return null;
    }
  }
  function safeHttpUrl(v) {
    if (typeof v !== "string" || v.length > 2e3) return null;
    try {
      const u = new URL(v);
      return u.protocol === "https:" || u.protocol === "http:" ? u.href : null;
    } catch {
      return null;
    }
  }
  var arr = (v, max) => Array.isArray(v) ? v.slice(0, max) : [];
  function cleanRecord(r, depth = 0) {
    if (!r || typeof r !== "object" || !isId(r.id)) return null;
    const a = r.author;
    if (!a || typeof a !== "object" || !isId(a.id) || !isHandle(a.handle)) return null;
    const created = typeof r.created_at === "string" ? Date.parse(r.created_at) : NaN;
    const rt = r.reply_to;
    return {
      id: r.id,
      created_at: Number.isFinite(created) ? new Date(created).toISOString() : null,
      text: str(r.text, MAX_TEXT) ?? "",
      lang: typeof r.lang === "string" && /^[a-z]{2,3}(-[A-Za-z]{2,4})?$/.test(r.lang) ? r.lang : null,
      reply_to: rt && isId(rt.id) ? { id: rt.id, handle: isHandle(rt.handle) ? rt.handle : null } : null,
      urls: arr(r.urls, 10).map((u) => ({ url: safeHttpUrl(u?.url), display: str(u?.display, 100) })).filter((u) => u.url),
      media: arr(r.media, 4).map((m) => ({ type: MEDIA_TYPES.has(m?.type) ? m.type : "photo", url: safeMediaUrl(m?.url) })).filter((m) => m.url),
      author: { id: a.id, handle: a.handle, name: str(a.name, 50) || a.handle, avatar: safeMediaUrl(a.avatar) },
      quoted: depth < 2 ? cleanRecord(r.quoted, 2) : null,
      retweeted: depth === 0 ? cleanRecord(r.retweeted, 1) : null
    };
  }

  // core/account.js
  function uidFromCookie(cookie) {
    const m = String(cookie || "").match(/(?:^|;\s*)twid="?u(?:%3D|=)(\d{1,20})/i);
    return m ? m[1] : null;
  }
  function handleFromDom(doc) {
    const href = doc.querySelector('a[data-testid="AppTabBar_Profile_Link"]')?.getAttribute("href") || "";
    const m = href.match(/^\/([A-Za-z0-9_]{1,15})$/);
    return m ? m[1] : null;
  }
  var sameHandle = (a, b) => typeof a === "string" && typeof b === "string" && a.toLowerCase() === b.toLowerCase();
  function cleanFeed(f) {
    if (!f || typeof f !== "object" || typeof f.id !== "string" || !/^[a-z0-9]{10}$/.test(f.id)) return null;
    const feed = { id: f.id, label: String(f.label || "").slice(0, 40) };
    const v = f.verified;
    if (v && isHandle(v.handle)) feed.verified = { handle: v.handle, at: Number(v.at) || 0 };
    return feed;
  }
  function cleanVerify(p, now) {
    return p && typeof p.code === "string" && /^[a-z0-9]{8}$/.test(p.code) && Number(p.until) > now ? { code: p.code, text: String(p.text || ""), until: Number(p.until) } : null;
  }
  var cleanShare = (s) => Object.fromEntries(KINDS.map((k) => [k, !!s?.[k]]));
  var newAccount = (handle) => ({
    handle: isHandle(handle) ? handle : null,
    paused: true,
    feed: null,
    share: { foryou: true, following: true },
    verify: null
  });
  function normalizeSettings(s, now = Date.now()) {
    const out = { open: false, paused: false, accounts: {}, legacy: null };
    if (!s || typeof s !== "object") return out;
    out.open = !!s.open;
    out.paused = !!s.paused;
    if (s.accounts && typeof s.accounts === "object") {
      for (const [uid, a] of Object.entries(s.accounts)) {
        if (!isId(uid) || !a || typeof a !== "object") continue;
        out.accounts[uid] = {
          handle: isHandle(a.handle) ? a.handle : null,
          paused: !!a.paused,
          feed: cleanFeed(a.feed),
          share: cleanShare(a.share),
          verify: cleanVerify(a.verify, now)
        };
      }
    }
    const feed = cleanFeed(s.legacy?.feed);
    if (feed) out.legacy = { feed, share: cleanShare(s.legacy.share), verify: cleanVerify(s.legacy.verify, now) };
    return out;
  }
  function migrateSettings(old, now = Date.now()) {
    return normalizeSettings({ open: old?.open, legacy: old?.feed ? { feed: old.feed, share: old.share, verify: old.verify } : null }, now);
  }
  function legacyFits(legacy, handle) {
    if (!legacy || !isHandle(handle)) return false;
    return sameHandle(legacy.feed.verified?.handle, handle) || sameHandle(legacy.feed.label.replace(/^@/, ""), handle);
  }

  // core/api.js
  var ApiError = class extends Error {
    constructor(status, data) {
      super(data?.error || `HTTP ${status}`);
      this.status = status;
      this.retryAfter = Number(data?.retry_after) || 0;
    }
  };
  var enc = (s) => encodeURIComponent(s).replace(/[!'()*~]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());
  var qs = (params) => Object.entries(params).filter(([, v]) => v != null && v !== "").map(([k, v]) => `${k}=${enc(String(v))}`).join("&");
  function createApi(request) {
    const call2 = async (method, path, body = null, auth = false) => {
      const { status, data } = await request(method, path, body, auth);
      if (status < 200 || status >= 300) throw new ApiError(status, data);
      return data;
    };
    return {
      listFeeds: ({ q, before, limit = 50 } = {}) => call2("GET", `/api/feeds?${qs({ limit, q, before })}`),
      search: (q, { feed, kind, offset, limit = 20 } = {}) => call2("GET", `/api/search?${qs({ q, feed, kind, offset, limit })}`),
      getFeed: (id, kind, before, limit = 30) => call2("GET", `/api/feeds/${enc(id)}?limit=${limit}` + (kind ? `&kind=${enc(kind)}` : "") + (before ? `&before=${enc(before)}` : "")),
      createFeed: (label) => call2("POST", "/api/feeds", { label }),
      push: (id, body) => call2("POST", `/api/feeds/${enc(id)}/items`, body, true),
      startVerify: (id) => call2("POST", `/api/feeds/${enc(id)}/verify`, {}, true),
      checkVerify: (id, tweetId) => call2("POST", `/api/feeds/${enc(id)}/verify/check`, { tweet_id: tweetId }, true),
      remove: (id) => call2("DELETE", `/api/feeds/${enc(id)}`, null, true),
      version: () => call2("GET", "/api/version")
    };
  }

  // core/parse.js
  var FEED_RE = /\/graphql\/[^/]+\/(HomeTimeline|HomeLatestTimeline)(\?|$)/;
  var kindOf = (op) => op === "HomeLatestTimeline" ? "following" : "foryou";
  function unwrap(r) {
    if (r && r.__typename === "TweetWithVisibilityResults") r = r.tweet;
    return r && r.legacy && r.rest_id ? r : null;
  }
  function userOf(r) {
    const u = r.core?.user_results?.result;
    if (!u || !u.rest_id) return null;
    return {
      id: u.rest_id,
      handle: u.core?.screen_name ?? u.legacy?.screen_name ?? null,
      name: u.core?.name ?? u.legacy?.name ?? null,
      avatar: u.avatar?.image_url ?? u.legacy?.profile_image_url_https ?? null,
      protected: !!(u.privacy?.protected ?? u.legacy?.protected)
    };
  }
  function decodeEntities(s) {
    return s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
  }
  function toRecord(r, depth) {
    const L = r.legacy;
    const author = userOf(r);
    if (!author || author.protected) return null;
    const note = r.note_tweet?.note_tweet_results?.result;
    const media2 = L.extended_entities?.media ?? L.entities?.media ?? [];
    const urls = note?.entity_set?.urls ?? L.entities?.urls ?? [];
    let text = note?.text ?? decodeEntities(L.full_text ?? "");
    for (const m of media2) if (m.url) text = text.split(m.url).join("");
    for (const u of urls) if (u.url && u.expanded_url) text = text.split(u.url).join(u.expanded_url);
    const rec = {
      id: r.rest_id,
      created_at: L.created_at ? new Date(L.created_at).toISOString() : null,
      text: text.trim(),
      lang: L.lang ?? null,
      reply_to: L.in_reply_to_status_id_str ? { id: L.in_reply_to_status_id_str, handle: L.in_reply_to_screen_name ?? null } : null,
      urls: urls.filter((u) => u.expanded_url).map((u) => ({ url: u.expanded_url, display: u.display_url ?? null })),
      media: media2.map((m) => ({ type: m.type, url: m.media_url_https })),
      author: { id: author.id, handle: author.handle, name: author.name, avatar: author.avatar },
      quoted: null,
      retweeted: null
    };
    if (depth < 2) {
      const q = unwrap(r.quoted_status_result?.result);
      if (q) rec.quoted = toRecord(q, 2);
    }
    if (depth === 0) {
      const rt = unwrap(L.retweeted_status_result?.result);
      if (rt) {
        rec.retweeted = toRecord(rt, 1);
        if (!rec.retweeted) return null;
      }
    }
    return rec;
  }
  function createdTweet(json) {
    const d = json?.data;
    const r = unwrap(d?.create_tweet?.tweet_results?.result ?? d?.notetweet_create?.tweet_results?.result);
    if (!r) return null;
    return { id: r.rest_id, text: r.note_tweet?.note_tweet_results?.result?.text ?? decodeEntities(r.legacy.full_text ?? "") };
  }
  function extractFeed(json) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    (function walk(node, promoted) {
      if (!node || typeof node !== "object") return;
      if (Array.isArray(node)) {
        for (const n of node) walk(n, promoted);
        return;
      }
      const p = promoted || !!node.promotedMetadata || typeof node.entryId === "string" && node.entryId.startsWith("promoted-");
      const t = node.tweet_results ? unwrap(node.tweet_results.result) : null;
      if (t && !p && !seen.has(t.rest_id)) {
        seen.add(t.rest_id);
        const rec = cleanRecord(toRecord(t, 0));
        if (rec) out.push(rec);
      }
      for (const k in node) if (k !== "tweet_results") walk(node[k], p);
    })(json?.data, false);
    return out;
  }

  // core/capture.js
  var CREATE_RE = /\/graphql\/[^/]+\/(CreateTweet|CreateNoteTweet)(\?|$)/;
  function installCapture(win, onFeed, onCreate = () => {
  }, tag = () => null) {
    const handlerFor = (url) => {
      const m = url.match(FEED_RE);
      if (m) return (json, t) => onFeed(kindOf(m[1]), json, t);
      return CREATE_RE.test(url) ? onCreate : null;
    };
    const tagNow = () => {
      try {
        return tag();
      } catch (_) {
        return null;
      }
    };
    const emit = (handler, t, status, getJson) => {
      if (status !== 200) return;
      Promise.resolve().then(getJson).then((json) => handler(json, t)).catch(() => {
      });
    };
    const origFetch = win.fetch;
    if (typeof origFetch === "function") {
      win.fetch = async function(...args) {
        let h = null;
        let t = null;
        try {
          const input = args[0];
          const url = typeof input === "string" ? input : input?.url ?? input?.href;
          h = url ? handlerFor(String(url)) : null;
          if (h) t = tagNow();
        } catch (_) {
          h = null;
        }
        const res = await origFetch.apply(this, args);
        try {
          if (h) emit(h, t, res.status, () => res.clone().json());
        } catch (_) {
        }
        return res;
      };
    }
    const XHR = win.XMLHttpRequest?.prototype;
    if (XHR) {
      const origOpen = XHR.open;
      const origSend = XHR.send;
      XHR.open = function(method, url, ...rest) {
        this.__xfsUrl = String(url);
        return origOpen.call(this, method, url, ...rest);
      };
      XHR.send = function(...args) {
        const h = this.__xfsUrl && handlerFor(this.__xfsUrl);
        if (h) {
          const t = tagNow();
          this.addEventListener("load", () => {
            emit(h, t, this.status, () => this.responseType === "json" ? this.response : JSON.parse(this.responseText));
          });
        }
        return origSend.apply(this, args);
      };
    }
  }

  // core/render.js
  var CSS = `
/* Contrast (WCAG): text and links >= 7:1 on --bg and --hover, control outlines (--edge) >= 3:1. */
.xfs{--bg:#fff;--fg:#0f1419;--muted:#38444d;--line:#cfd9de;--edge:#77858f;--hover:#eef2f5;--accent:#0a58a8;--danger:#c0111f;
  font:15px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;color:var(--fg);background:var(--bg)}
.xfs.dark{--bg:#000;--fg:#f4f6f7;--muted:#b6bec5;--line:#3a4046;--edge:#7c8790;--hover:#16181c;--accent:#5ab8ff;--danger:#ff7070}
.xfs *{box-sizing:border-box}
.xfs a{color:var(--accent);text-decoration:none}
.xfs a:hover{text-decoration:underline}
.xfs-card{padding:12px 14px;border-bottom:1px solid var(--line)}
.xfs-rt{color:var(--muted);font-size:14px;margin:0 0 4px 50px}
.xfs-rt a{color:inherit;font-weight:600}
.xfs-tweet{display:grid;grid-template-columns:40px minmax(0,1fr);gap:0 10px}
.xfs-av{width:40px;height:40px;border-radius:50%;background:var(--line);display:block;object-fit:cover}
.xfs-head{display:flex;gap:4px;align-items:baseline;min-width:0;white-space:nowrap;overflow:hidden}
.xfs-head .xfs-av{width:20px;height:20px;align-self:center}
.xfs-name{font-weight:700;color:var(--fg)!important;overflow:hidden;text-overflow:ellipsis}
.xfs-handle,.xfs-time,.xfs-muted{color:var(--muted)!important}
.xfs-handle{overflow:hidden;text-overflow:ellipsis}
.xfs-reply{color:var(--muted);font-size:14px}
.xfs-text{white-space:pre-wrap;overflow-wrap:anywhere;margin-top:2px}
.xfs-media{display:grid;grid-template-columns:1fr 1fr;gap:2px;margin-top:8px;border-radius:12px;overflow:hidden;border:1px solid var(--line)}
.xfs-media.n1{grid-template-columns:1fr}
.xfs-media a{position:relative;display:block;aspect-ratio:16/9;background:var(--line)}
.xfs-media img{width:100%;height:100%;object-fit:cover;display:block}
.xfs-play{position:absolute;inset:0;display:grid;place-items:center;font-size:28px;color:#fff;text-shadow:0 1px 6px #000}
.xfs-quote{border:1px solid var(--line);border-radius:12px;padding:8px 10px;margin-top:8px}
.xfs-session{padding:6px 14px;font-size:13px;font-weight:600;color:var(--muted);background:var(--hover);border-bottom:1px solid var(--line)}
.xfs-note{padding:16px 14px;color:var(--muted)}
.xfs-small{font-size:13px}
.xfs-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.xfs-btn{font:inherit;font-size:14px;font-weight:700;padding:5px 12px;border-radius:999px;border:1px solid var(--edge);
  background:var(--bg);color:var(--fg);cursor:pointer}
.xfs-btn:hover{background:var(--hover)}
.xfs-btn.on{background:var(--fg);color:var(--bg);border-color:var(--fg)}
.xfs-btn:disabled{opacity:.55;cursor:default}
.xfs-more{display:block;margin:12px auto}
.xfs-feedhead{padding:12px 14px;border-bottom:1px solid var(--line);display:grid;gap:8px}
.xfs-feed{display:block;width:100%;text-align:left;padding:10px 14px;border:0;border-bottom:1px solid var(--line);
  background:none;color:inherit;font:inherit;cursor:pointer}
.xfs-feed:hover{background:var(--hover)}
.xfs-label{font-weight:700;overflow-wrap:anywhere}
.xfs-searchbox{display:grid;gap:6px;padding:10px 14px;border-bottom:1px solid var(--line)}
.xfs-search{display:flex;gap:8px}
.xfs-search input{flex:1;min-width:0;font:inherit;padding:6px 12px;border-radius:999px;border:1px solid var(--edge);
  background:var(--hover);color:var(--fg);outline:none}
.xfs-search input::placeholder{color:var(--muted);opacity:1}
.xfs-search input:focus{border-color:var(--accent);background:var(--bg);box-shadow:0 0 0 1px var(--accent)}
.xfs-scope{font-size:13px;color:var(--muted)}
.xfs-scope .xfs-chip{margin-left:6px}
.xfs-scope b{color:var(--fg)}
.xfs-h{padding:12px 14px 4px;font-weight:700;font-size:14px;color:var(--muted);border-bottom:1px solid var(--line)}
.xfs-seen{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:8px 0 0 50px;font-size:13px;color:var(--muted)}
.xfs-chip{font:inherit;font-size:13px;font-weight:600;padding:2px 9px;border-radius:999px;border:1px solid var(--edge);background:none;
  color:var(--fg);cursor:pointer;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.xfs-chip:hover{background:var(--hover)}
.xfs-badge{display:inline-flex;align-items:center;gap:3px;font-size:13px;font-weight:700;color:var(--accent)!important;white-space:nowrap}
`;
  function isolateKeys(input) {
    for (const t of ["keydown", "keyup", "keypress"]) input.addEventListener(t, (e) => e.stopPropagation());
  }
  function el(doc, tag, cls, text) {
    const e = doc.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function link(doc, href, cls, text) {
    const a = el(doc, "a", cls, text);
    a.href = href;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    return a;
  }
  function img(doc, src, cls) {
    const i = el(doc, "img", cls);
    i.src = src;
    i.alt = "";
    i.loading = "lazy";
    i.referrerPolicy = "no-referrer";
    return i;
  }
  var profileUrl = (h) => `https://x.com/${h}`;
  var statusUrl = (r) => `https://x.com/${r.author.handle}/status/${r.id}`;
  function relTime(iso, now = Date.now()) {
    const t = Date.parse(iso);
    if (!Number.isFinite(t)) return "";
    const s = Math.max(0, (now - t) / 1e3);
    if (s < 60) return "now";
    if (s < 3600) return `${Math.floor(s / 60)}m`;
    if (s < 86400) return `${Math.floor(s / 3600)}h`;
    const d = new Date(t);
    const opts = { month: "short", day: "numeric" };
    if (d.getFullYear() !== new Date(now).getFullYear()) opts.year = "numeric";
    return d.toLocaleDateString(void 0, opts);
  }
  function ago(ms, now = Date.now()) {
    if (!ms) return "never";
    const s = Math.max(0, (now - ms) / 1e3);
    if (s < 90) return "just now";
    if (s < 3600) return `${Math.round(s / 60)} min ago`;
    if (s < 86400) return `${Math.round(s / 3600)} h ago`;
    return `${Math.round(s / 86400)} days ago`;
  }
  function sessionLabel(ms) {
    return "Seen " + new Date(ms).toLocaleString(
      void 0,
      { weekday: "short", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }
    );
  }
  function shorten(u) {
    const s = u.replace(/^https?:\/\/(www\.)?/, "");
    return s.length > 32 ? s.slice(0, 31) + "…" : s;
  }
  var TOKEN = /https?:\/\/[^\s]+|@[A-Za-z0-9_]{1,15}|#[\p{L}\p{N}_]+/gu;
  function appendText(doc, parent, text, urls) {
    const display = new Map(urls.map((u) => [u.url, u.display]));
    let last = 0;
    for (const m of text.matchAll(TOKEN)) {
      const i = m.index;
      let tok = m[0];
      let href;
      if (tok[0] === "h") {
        if (!display.has(tok)) tok = tok.replace(/[.,!?;:)\]'"»…]+$/, "");
        href = safeHttpUrl(tok);
      } else {
        if (i > 0 && /[\p{L}\p{N}_&]/u.test(text[i - 1])) continue;
        href = tok[0] === "@" ? profileUrl(tok.slice(1)) : `https://x.com/hashtag/${encodeURIComponent(tok.slice(1))}`;
      }
      if (!href) continue;
      if (i > last) parent.append(doc.createTextNode(text.slice(last, i)));
      parent.append(link(doc, href, null, tok[0] === "h" ? display.get(tok) || shorten(tok) : tok));
      last = i + tok.length;
    }
    if (last < text.length) parent.append(doc.createTextNode(text.slice(last)));
  }
  function media(doc, r) {
    const box = el(doc, "div", "xfs-media" + (r.media.length === 1 ? " n1" : ""));
    for (const m of r.media) {
      const a = link(doc, statusUrl(r));
      const u = new URL(m.url);
      if (!u.search) u.searchParams.set("name", "small");
      a.append(img(doc, u.href));
      if (m.type !== "photo") a.append(el(doc, "span", "xfs-play", "▶"));
      box.append(a);
    }
    return box;
  }
  function tweetBody(doc, r, nested) {
    const main = el(doc, "div");
    const head = el(doc, "div", "xfs-head");
    if (nested && r.author.avatar) head.append(img(doc, r.author.avatar, "xfs-av"));
    head.append(link(doc, profileUrl(r.author.handle), "xfs-name", r.author.name));
    head.append(link(doc, profileUrl(r.author.handle), "xfs-handle", "@" + r.author.handle));
    head.append(el(doc, "span", "xfs-muted", "·"));
    const time = link(doc, statusUrl(r), "xfs-time", relTime(r.created_at) || "open");
    time.title = "Open on X" + (r.created_at ? ` · ${new Date(r.created_at).toLocaleString()}` : "");
    head.append(time);
    main.append(head);
    if (r.reply_to) {
      const rep = el(doc, "div", "xfs-reply", "Replying to ");
      if (r.reply_to.handle) rep.append(link(doc, profileUrl(r.reply_to.handle), null, "@" + r.reply_to.handle));
      else rep.append(link(doc, `https://x.com/i/status/${r.reply_to.id}`, null, "a post"));
      main.append(rep);
    }
    if (r.text) {
      const t = el(doc, "div", "xfs-text");
      appendText(doc, t, r.text, r.urls);
      main.append(t);
    }
    if (r.media.length) main.append(media(doc, r));
    if (r.quoted) main.append(tweetBody(doc, r.quoted, true));
    if (nested) {
      main.className = "xfs-quote";
      return main;
    }
    const wrap = el(doc, "div", "xfs-tweet");
    const av = link(doc, profileUrl(r.author.handle));
    av.append(r.author.avatar ? img(doc, r.author.avatar, "xfs-av") : el(doc, "span", "xfs-av"));
    wrap.append(av, main);
    return wrap;
  }
  function renderTweet(doc, raw) {
    const r = cleanRecord(raw);
    if (!r) return null;
    const card = el(doc, "article", "xfs-card");
    if (r.retweeted) {
      const rt = el(doc, "div", "xfs-rt", "↻ ");
      rt.append(link(doc, profileUrl(r.author.handle), null, r.author.name), doc.createTextNode(" reposted"));
      card.append(rt, tweetBody(doc, r.retweeted, false));
    } else {
      card.append(tweetBody(doc, r, false));
    }
    return card;
  }

  // core/browse.js
  var KIND_TABS = [["following", "Following"], ["foryou", "For You"]];
  var KIND_NAME = Object.fromEntries(KIND_TABS);
  function errorText(e) {
    if (e.status === 400) return "Type at least one word to search for.";
    if (e.status === 429) return "Too many requests. Wait a minute and try again.";
    return e.message;
  }
  function searchForm(doc, placeholder, value, onSubmit) {
    const form = el(doc, "form", "xfs-search");
    const input = el(doc, "input");
    input.type = "search";
    input.placeholder = placeholder;
    input.value = value || "";
    input.maxLength = 200;
    input.setAttribute("aria-label", placeholder);
    isolateKeys(input);
    const button = el(doc, "button", "xfs-btn", "Search");
    button.type = "submit";
    form.append(input, button);
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const q = input.value.trim();
      if (q) onSubmit(q);
    });
    return form;
  }
  var searchBox = (doc, ...parts) => {
    const b = el(doc, "div", "xfs-searchbox");
    b.append(...parts);
    return b;
  };
  var moreButton = (doc) => el(doc, "button", "xfs-btn xfs-more", "Load more");
  function badge(doc, handle, asLink) {
    if (!isHandle(handle)) return null;
    const b = el(doc, asLink ? "a" : "span", "xfs-badge", `✓ @${handle}`);
    b.title = `Published by @${handle} (account verified)`;
    if (asLink) {
      b.href = `https://x.com/${handle}`;
      b.target = "_blank";
      b.rel = "noopener noreferrer";
    }
    return b;
  }
  function feedButton(doc, f, nav) {
    const b = el(doc, "button", "xfs-feed");
    const kinds = KIND_TABS.filter(([k]) => f[`${k}_at`]).map(([, name2]) => name2).join(" · ");
    const name = el(doc, "div", "xfs-row");
    name.append(el(doc, "span", "xfs-label", f.label));
    const v = badge(doc, f.verified_handle, false);
    if (v) name.append(v);
    b.append(name, el(doc, "div", "xfs-muted xfs-small", `${kinds || "No recent posts"} · active ${ago(f.last_push_at)}`));
    b.onclick = () => nav.openFeed(f.id);
    return b;
  }
  async function renderDirectory(doc, mount, api, nav) {
    const list = el(doc, "div");
    const more = moreButton(doc);
    const hint = el(doc, "div", "xfs-scope", "Searches posts in every shared feed, and feed names. To search just one person’s feed, open it and use its own search box.");
    mount.replaceChildren(searchBox(doc, searchForm(doc, "Search all feeds", "", (q) => nav.search(q)), hint), list);
    list.append(el(doc, "div", "xfs-note", "Loading shared feeds…"));
    let next = null;
    async function load(first) {
      more.disabled = true;
      let data;
      try {
        data = await api.listFeeds({ before: next });
      } catch (e) {
        if (first) list.replaceChildren(el(doc, "div", "xfs-note", `Could not load feeds: ${errorText(e)}`));
        else {
          more.disabled = false;
          more.textContent = "Retry";
        }
        return;
      }
      if (first) list.replaceChildren();
      more.remove();
      if (first && !data.feeds.length) list.append(el(doc, "div", "xfs-note", "No feeds shared in the last 14 days."));
      for (const f of data.feeds) list.append(feedButton(doc, f, nav));
      next = data.next;
      more.textContent = "Load more";
      more.disabled = false;
      if (next) list.append(more);
    }
    more.onclick = () => load(false);
    await load(true);
  }
  async function renderSearch(doc, mount, api, q, nav, opts = {}) {
    const { feed, feedLabel } = opts;
    const top = el(doc, "div", "xfs-feedhead");
    const back = el(doc, "button", "xfs-btn", feed ? "← Back to feed" : "← All feeds");
    back.onclick = () => feed ? nav.openFeed(feed) : nav.home();
    const row = el(doc, "div", "xfs-row");
    row.append(back);
    top.append(row);
    const scope = el(doc, "div", "xfs-scope");
    if (feed) {
      const all = el(doc, "button", "xfs-chip", "Search all feeds instead");
      all.onclick = () => nav.search(q);
      scope.append(doc.createTextNode("Results only from "), el(doc, "b", null, feedLabel || "one feed"), all);
    } else {
      scope.append(
        doc.createTextNode("Results from "),
        el(doc, "b", null, "all shared feeds"),
        doc.createTextNode(". To search one person’s feed only, open it and search there.")
      );
    }
    const feedsBox = el(doc, "div");
    const posts = el(doc, "div");
    const more = moreButton(doc);
    mount.replaceChildren(searchBox(doc, searchForm(
      doc,
      feed ? "Search only this feed" : "Search all feeds",
      q,
      (nq) => nav.search(nq, feed, feedLabel)
    ), scope), top, feedsBox, posts);
    posts.append(el(doc, "div", "xfs-note", "Searching…"));
    if (!feed) {
      api.listFeeds({ q, limit: 10 }).then((data) => {
        if (!data.feeds.length) return;
        feedsBox.append(el(doc, "div", "xfs-h", "Feeds"));
        for (const f of data.feeds) feedsBox.append(feedButton(doc, f, nav));
        feedsBox.append(el(doc, "div", "xfs-h", "Posts"));
      }, () => {
      });
    }
    let offset = 0;
    async function load(first) {
      more.disabled = true;
      let data;
      try {
        data = await api.search(q, { feed, offset });
      } catch (e) {
        if (first) posts.replaceChildren(el(doc, "div", "xfs-note", `Search failed: ${errorText(e)}`));
        else {
          more.disabled = false;
          more.textContent = "Retry";
        }
        return;
      }
      if (first) posts.replaceChildren();
      more.remove();
      if (first && !data.results.length) {
        posts.append(el(doc, "div", "xfs-note", `No posts match “${q}” in the last 14 days.`));
      }
      for (const r of data.results) {
        const card = renderTweet(doc, r.tweet);
        if (!card) continue;
        card.append(seenLine(doc, r.seen, nav, !!feed));
        posts.append(card);
      }
      offset = data.next;
      more.textContent = "Load more";
      more.disabled = false;
      if (offset != null) posts.append(more);
    }
    more.onclick = () => load(false);
    await load(true);
  }
  function seenLine(doc, seen, nav, scoped) {
    const line = el(doc, "div", "xfs-seen", scoped ? "Seen " : "Seen in ");
    const shown = scoped ? seen.slice(0, 1) : seen.slice(0, 3);
    for (const s of shown) {
      const who = isHandle(s.verified) ? `✓ @${s.verified}` : s.label;
      const text = scoped ? `${KIND_NAME[s.kind] || s.kind} · ${ago(s.session)}` : `${who} · ${KIND_NAME[s.kind] || s.kind} · ${ago(s.session)}`;
      const chip = el(doc, "button", "xfs-chip", text);
      chip.onclick = () => nav.openFeed(s.feed_id, s.kind);
      line.append(chip);
    }
    if (!scoped && seen.length > shown.length) line.append(el(doc, "span", null, `+${seen.length - shown.length} more`));
    return line;
  }
  async function renderFeed(doc, mount, api, id, opts = {}) {
    let kind = opts.kind || null;
    let next = null;
    let lastSession = null;
    const head = el(doc, "div", "xfs-feedhead");
    const list = el(doc, "div");
    const more = moreButton(doc);
    mount.replaceChildren(el(doc, "div", "xfs-note", "Loading…"));
    function drawHead(feed) {
      const top = el(doc, "div", "xfs-row");
      if (opts.back) {
        const b = el(doc, "button", "xfs-btn", "← All feeds");
        b.onclick = opts.back;
        top.append(b);
      }
      top.append(el(doc, "span", "xfs-label", feed.label));
      const v = badge(doc, feed.verified_handle, true);
      if (v) top.append(v);
      const tabs = el(doc, "div", "xfs-row");
      for (const [k, name] of KIND_TABS) {
        const t = el(doc, "button", "xfs-btn" + (k === kind ? " on" : ""), name);
        t.disabled = !feed[`${k}_at`] && k !== kind;
        t.onclick = () => {
          if (k !== kind) {
            kind = k;
            opts.onKind?.(k);
            load(true);
          }
        };
        tabs.append(t);
      }
      if (opts.shareUrl) {
        const a = el(doc, "a", "xfs-small", "Public link ↗");
        a.href = opts.shareUrl;
        a.target = "_blank";
        a.rel = "noopener";
        tabs.append(a);
      }
      const who = v ? `Published by @${feed.verified_handle}, who proved control of that account on ${new Date(feed.verified_at).toLocaleDateString()}.` : "The name is self-described and not verified.";
      head.replaceChildren(top, tabs, el(
        doc,
        "div",
        "xfs-muted xfs-small",
        `${who} Posts are shown as the publisher uploaded them; open one on X to check it. Entries expire after 14 days.`
      ));
      if (opts.onSearch) head.append(searchForm(doc, "Search only this feed", "", (q) => opts.onSearch(q, feed.label)));
    }
    async function load(reset) {
      more.disabled = true;
      let data;
      try {
        data = await api.getFeed(id, kind, reset ? null : next);
      } catch (e) {
        const msg = e.status === 404 ? "Feed not found. It may have been deleted." : `Could not load feed: ${e.message}`;
        if (reset) mount.replaceChildren(el(doc, "div", "xfs-note", msg));
        else {
          more.disabled = false;
          more.textContent = "Retry";
        }
        return;
      }
      if (reset) {
        kind = data.kind;
        drawHead(data.feed);
        list.replaceChildren();
        lastSession = null;
        mount.replaceChildren(head, list);
      }
      more.remove();
      for (const it of data.items) {
        if (it.session !== lastSession) {
          list.append(el(doc, "div", "xfs-session", sessionLabel(it.session)));
          lastSession = it.session;
        }
        const card = renderTweet(doc, it.tweet);
        if (card) list.append(card);
      }
      if (reset && !data.items.length) list.append(el(doc, "div", "xfs-note", "Nothing shared here in the last 14 days."));
      next = data.next;
      more.textContent = "Load more";
      more.disabled = false;
      if (next) list.append(more);
    }
    more.onclick = () => load(false);
    await load(true);
  }

  // core/panel.js
  var PANEL_CSS = `
.wrap{position:fixed;right:12px;top:12px;z-index:2147483647;display:flex;flex-direction:column;align-items:flex-end;gap:10px;background:none;
  --on:#00a63e;--on-glow:rgba(0,166,62,.5);--off:#e8131b;--off-glow:rgba(232,19,27,.45)}
.wrap.dark{--on:#2bd968;--on-glow:rgba(43,217,104,.55);--off:#ff4545;--off-glow:rgba(255,69,69,.5);--hover:rgba(255,255,255,.08)}
.bar{display:flex;gap:6px;align-items:center}
/* Same border width in every state, and the dot only turns invisible, so nothing moves when states change. */
.split,.mini{display:flex;align-items:center;height:34px;border-radius:999px;border:2px solid var(--off);background:var(--bg);
  box-shadow:0 0 10px 1px var(--off-glow),0 2px 10px rgba(0,0,0,.12)}
.split.on,.mini.on{border-color:var(--on);box-shadow:0 0 10px 1px var(--on-glow),0 2px 10px rgba(0,0,0,.12)}
.split{overflow:hidden}
.split button,.mini{font:inherit;font-weight:700;color:var(--fg);cursor:pointer}
.split button{height:100%;background:none;border:0}
.mini{max-width:130px;font-size:12px;padding:0 11px}
.mini span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.split button:hover,.mini:hover{background:var(--hover)}
.split .main{display:flex;align-items:center;gap:7px;font-size:13px;padding:0 9px 0 11px}
.caret{display:grid;place-items:center;width:26px;padding:0 4px 0 0}
.caret i{width:0;height:0;border-left:4.5px solid transparent;border-right:4.5px solid transparent;border-top:5.5px solid currentColor;
  transition:transform .15s}
.caret[aria-expanded=true] i{transform:rotate(180deg)}
.dot{flex:none;width:8px;height:8px;border-radius:50%;background:var(--on);box-shadow:0 0 6px 2px var(--on-glow);visibility:hidden}
.split.live .dot{visibility:visible}
.callout{position:relative;width:320px;max-width:calc(100vw - 24px);display:grid;gap:8px;padding:12px 14px;border-radius:14px;
  border:2px solid var(--accent);background:var(--bg);color:var(--fg);box-shadow:0 6px 28px rgba(0,0,0,.28);animation:xfs-pop .25s ease-out}
.callout::before{content:"";position:absolute;top:-9px;right:26px;border:8px solid transparent;border-top:0;border-bottom:9px solid var(--accent)}
.callout-title{font-weight:800;font-size:15px}
.callout .xfs-row{margin-top:2px}
.callout.update{background:var(--accent);color:var(--bg);animation:xfs-pop .25s ease-out,xfs-ring 1.4s ease-out .3s 3}
.callout.update .xfs-btn{background:none;color:var(--bg);border-color:var(--bg)}
.callout.update .xfs-btn.primary{background:var(--bg);color:var(--accent)}
.xfs-btn.primary{background:var(--accent);border-color:var(--accent);color:var(--bg)}
.xfs-btn.primary:hover{filter:brightness(1.1)}
@keyframes xfs-pop{from{opacity:0;transform:translateY(-6px) scale(.97)}}
@keyframes xfs-ring{from{box-shadow:0 0 0 0 var(--accent),0 6px 28px rgba(0,0,0,.28)}to{box-shadow:0 0 0 16px transparent,0 6px 28px rgba(0,0,0,.28)}}
@media (prefers-reduced-motion:reduce){.callout{animation:none!important}}
.box{width:400px;max-width:calc(100vw - 24px);max-height:min(calc(100vh - 72px),720px);display:flex;flex-direction:column;background:var(--bg);
  border:1px solid var(--edge);border-radius:16px;box-shadow:0 4px 24px rgba(0,0,0,.22);overflow:hidden}
.tabs{display:flex;border-bottom:1px solid var(--line)}
.tab{flex:1;padding:10px;background:none;border:0;border-bottom:2px solid transparent;font:inherit;font-weight:700;color:var(--muted);cursor:pointer}
.tab.on{color:var(--fg);border-bottom-color:var(--accent)}
.body{overflow-y:auto;flex:1;min-height:120px}
.share{padding:12px 14px;display:grid;gap:12px}
.toggle{display:flex;gap:10px;align-items:flex-start;cursor:pointer}
.toggle input{margin-top:3px;accent-color:var(--accent)}
.err{color:var(--danger);font-size:13px;font-weight:600}
.err:empty{display:none}
.notice{font-size:13px;font-weight:600;padding:8px 10px;border-radius:8px;background:var(--hover);border-left:3px solid var(--accent)}
.notice:empty{display:none}
.url{font-size:13px;overflow-wrap:anywhere}
.feedinfo{display:grid;gap:8px}
.pending{display:grid;gap:8px;padding:10px;border:1px solid var(--line);border-radius:12px}
.code{font:13px/1.4 ui-monospace,SFMono-Regular,Menlo,monospace;padding:8px;border-radius:8px;background:var(--hover);overflow-wrap:anywhere;user-select:all}
`;
  var KIND_ORDER = [["following", "Share my Following feed"], ["foryou", "Share my For You feed"]];
  function pageTheme(win, doc) {
    const bg = win.getComputedStyle(doc.body).backgroundColor || "";
    const [r, g, b, a = 1] = (bg.match(/\d+(\.\d+)?/g) || []).map(Number);
    if (r === void 0 || a === 0) return { dark: false, bg: null };
    return { dark: 0.2126 * r + 0.7152 * g + 0.0722 * b < 128, bg };
  }
  function miniButton(doc) {
    const b = el(doc, "button", "mini");
    const text = el(doc, "span");
    b.append(text);
    return {
      b,
      set(label, on, pressed, title) {
        text.textContent = label;
        b.classList.toggle("on", on);
        b.setAttribute("aria-pressed", String(pressed));
        b.title = title;
        b.setAttribute("aria-label", title);
      }
    };
  }
  function describe(v) {
    const who = v.handle ? "@" + v.handle : "this account";
    const btn = `“${v.handle ? who : "Account"}”`;
    return {
      "signed-out": "Sign in to X to share your feed.",
      loading: "Checking which X account is signed in…",
      stale: "This tab still shows the X account you had before switching. Reload the page.",
      "paused-all": "All uploads are paused, for every account.",
      new: `${who} isn’t set up yet. Choose in the box under the Feeds button.`,
      off: `${who} isn’t shared. Click ${btn} next to Feeds to share it.`,
      paused: `Uploads for ${who} are paused. Click ${btn} next to Feeds to resume.`,
      creating: v.creating ? "Creating your public feed…" : `${who}’s public feed isn’t created yet.`,
      none: `Both boxes are unticked, so nothing from ${who} is shared.`,
      active: `Sharing ${who}: Home posts upload as you scroll.`
    }[v.status];
  }
  function mountPanel(doc, win, app) {
    const host = doc.createElement("div");
    const root = host.attachShadow({ mode: "closed" });
    const style = el(doc, "style");
    style.textContent = CSS + PANEL_CSS;
    const wrap = el(doc, "div", "xfs wrap");
    const box = el(doc, "div", "box");
    const split = el(doc, "div", "split");
    const main = el(doc, "button", "main");
    main.append(el(doc, "span", "dot"), doc.createTextNode("Feeds"));
    main.onclick = () => app.togglePauseAll();
    const caret = el(doc, "button", "caret");
    caret.append(el(doc, "i"));
    caret.title = "Menu";
    caret.setAttribute("aria-label", "Feeds menu");
    caret.onclick = () => app.setOpen(!app.settings.open);
    split.append(main, caret);
    const acctBtn = miniButton(doc);
    acctBtn.b.onclick = () => app.togglePauseAccount();
    const bar = el(doc, "div", "bar");
    bar.append(acctBtn.b, split);
    const ask = el(doc, "div", "callout");
    const askTitle = el(doc, "div", "callout-title");
    const askText = el(doc, "div", "xfs-small");
    const askRow = el(doc, "div", "xfs-row");
    const yesBtn = el(doc, "button", "xfs-btn primary");
    yesBtn.onclick = () => app.decide(true);
    const noBtn = el(doc, "button", "xfs-btn");
    noBtn.onclick = () => app.view().prompt?.again ? app.dismissPrompt() : app.decide(false);
    const reloadBtn = el(doc, "button", "xfs-btn primary", "Reload page");
    reloadBtn.onclick = () => app.reload();
    askRow.append(yesBtn, noBtn, reloadBtn);
    const legacyRow = el(doc, "div", "xfs-row xfs-small");
    const legacyText = el(doc, "span");
    const legacyBtn = el(doc, "button", "xfs-btn");
    legacyBtn.onclick = () => app.useLegacy();
    legacyRow.append(legacyText, legacyBtn);
    ask.append(askTitle, askText, askRow, legacyRow);
    const upd = el(doc, "div", "callout update");
    upd.setAttribute("role", "status");
    const updText = el(doc, "div", "xfs-small");
    const updRow = el(doc, "div", "xfs-row");
    const updBtn = el(doc, "button", "xfs-btn primary");
    updBtn.onclick = () => app.updateStarted ? app.reload() : app.startUpdate();
    const laterBtn = el(doc, "button", "xfs-btn", "Later");
    laterBtn.onclick = () => app.snoozeUpdate();
    updRow.append(updBtn, laterBtn);
    upd.append(el(doc, "div", "callout-title", "Update available"), updText, updRow);
    const tabShare = el(doc, "button", "tab", "Share");
    const tabBrowse = el(doc, "button", "tab", "Browse");
    const tabs = el(doc, "div", "tabs");
    tabs.append(tabShare, tabBrowse);
    const body = el(doc, "div", "body");
    box.append(tabs, body);
    wrap.append(bar, ask, upd, box);
    root.append(style, wrap);
    doc.body.append(host);
    const share = el(doc, "div", "share");
    const feedInfo = el(doc, "div", "feedinfo");
    const feedRow = el(doc, "div", "xfs-row");
    const feedLabel = el(doc, "span", "xfs-label");
    feedRow.append(el(doc, "span", "xfs-muted", "Public feed:"), feedLabel);
    const linkRow = el(doc, "div", "xfs-row");
    const feedLink = el(doc, "a", "url");
    feedLink.target = "_blank";
    feedLink.rel = "noopener";
    const copyBtn = el(doc, "button", "xfs-btn", "Copy link");
    copyBtn.onclick = () => win.navigator.clipboard.writeText(feedLink.href).then(() => {
      copyBtn.textContent = "Copied";
    }, () => {
    });
    linkRow.append(feedLink, copyBtn);
    const verifiedLine = el(doc, "div", "xfs-badge");
    const verifyRow = el(doc, "div", "xfs-row");
    const verifyBtn = el(doc, "button", "xfs-btn");
    verifyBtn.onclick = () => app.startVerify();
    const verifyHint = el(doc, "span", "xfs-muted xfs-small");
    verifyRow.append(verifyBtn, verifyHint);
    const pending2 = el(doc, "div", "pending");
    const pendingText = el(doc, "div", "code");
    const pendingBtns = el(doc, "div", "xfs-row");
    const reopenBtn = el(doc, "button", "xfs-btn", "Open composer again");
    reopenBtn.onclick = () => app.openComposer();
    const cancelBtn = el(doc, "button", "xfs-btn", "Cancel");
    cancelBtn.onclick = () => app.cancelVerify();
    pendingBtns.append(reopenBtn, cancelBtn);
    const pasteForm = el(doc, "form", "xfs-search");
    const pasteInput = el(doc, "input");
    pasteInput.placeholder = "Posted it elsewhere? Paste the link";
    pasteInput.maxLength = 300;
    isolateKeys(pasteInput);
    const pasteBtn = el(doc, "button", "xfs-btn", "Check");
    pasteBtn.type = "submit";
    pasteForm.append(pasteInput, pasteBtn);
    pasteForm.addEventListener("submit", (e) => {
      e.preventDefault();
      app.checkVerifyLink(pasteInput.value);
    });
    pending2.append(
      el(
        doc,
        "div",
        "xfs-small",
        "Post this from your X account. A composer opened in a new tab: check the text and click Post. You can delete the post once verified."
      ),
      pendingText,
      pendingBtns,
      pasteForm
    );
    feedInfo.append(feedRow, linkRow, verifiedLine, verifyRow, pending2);
    const toggles = {};
    share.append(feedInfo);
    for (const [kind, text] of KIND_ORDER) {
      const label = el(doc, "label", "toggle");
      const input = el(doc, "input");
      input.type = "checkbox";
      input.onchange = () => app.toggleShare(kind, input.checked);
      const desc = el(doc, "div");
      const stat = el(doc, "div", "xfs-muted xfs-small");
      desc.append(el(doc, "div", "xfs-label", text), stat);
      label.append(input, desc);
      toggles[kind] = { label, input, stat };
      share.append(label);
    }
    const seenLine2 = el(doc, "div", "xfs-muted xfs-small");
    const noticeLine = el(doc, "div", "notice");
    const errLine = el(doc, "div", "err");
    const btnRow = el(doc, "div", "xfs-row");
    const flushBtn = el(doc, "button", "xfs-btn", "Upload now");
    flushBtn.onclick = () => app.flushNow();
    const delBtn = el(doc, "button", "xfs-btn", "Delete my feed");
    delBtn.onclick = () => app.deleteFeed();
    btnRow.append(flushBtn, delBtn);
    const othersLine = el(doc, "div", "xfs-muted xfs-small");
    share.append(seenLine2, noticeLine, errLine, btnRow, othersLine, el(
      doc,
      "div",
      "xfs-muted xfs-small",
      "Every X account asks before its first upload, and has its own feed. Ads and posts from protected accounts are never shared. Shared entries expire after 14 days."
    ));
    const browse = el(doc, "div");
    const nav = {
      home: () => {
        body.scrollTop = 0;
        return renderDirectory(doc, browse, app.api, nav);
      },
      openFeed: (id, kind) => {
        body.scrollTop = 0;
        return renderFeed(
          doc,
          browse,
          app.api,
          id,
          { kind, back: nav.home, shareUrl: app.publicUrl(id), onSearch: (q, label) => nav.search(q, id, label) }
        );
      },
      search: (q, feed, feedLabel2) => {
        body.scrollTop = 0;
        return renderSearch(doc, browse, app.api, q, nav, { feed, feedLabel: feedLabel2 });
      }
    };
    const openDirectory = nav.home;
    let tab = "share";
    function showTab(t) {
      const again = t === tab;
      tab = t;
      tabShare.classList.toggle("on", t === "share");
      tabBrowse.classList.toggle("on", t === "browse");
      body.replaceChildren(t === "share" ? share : browse);
      if (t === "browse" && (again || !browse.childNodes.length)) openDirectory();
    }
    tabShare.onclick = () => showTab("share");
    tabBrowse.onclick = () => showTab("browse");
    showTab("share");
    function render() {
      const { settings } = app;
      const v = app.view();
      const a = v.acct;
      const st = v.stats;
      const who = v.handle ? "@" + v.handle : "this account";
      const show = (e, on) => {
        e.style.display = on ? "" : "none";
      };
      const theme = pageTheme(win, doc);
      wrap.classList.toggle("dark", theme.dark);
      if (theme.dark) wrap.style.setProperty("--bg", theme.bg);
      else wrap.style.removeProperty("--bg");
      wrap.style.visibility = app.ready ? "" : "hidden";
      const status = describe(v);
      split.classList.toggle("on", !settings.paused);
      split.classList.toggle("live", v.status === "active");
      const mainTitle = `${status} ${settings.paused ? "Click to resume (accounts you paused yourself stay paused)." : "Click to pause uploads for every account (each account keeps its own switch)."}`;
      main.title = mainTitle;
      main.setAttribute("aria-label", `Feeds: ${mainTitle}`);
      main.setAttribute("aria-pressed", String(settings.paused));
      caret.setAttribute("aria-expanded", String(!!settings.open));
      show(acctBtn.b, v.uid);
      acctBtn.set(
        v.handle ? "@" + v.handle : "Account",
        !!a && !a.paused,
        !!a?.paused,
        !a ? `${who} isn’t set up. Click to choose whether to share it.` : a.paused ? `${who} is paused. Click to resume its uploads.` : `${who} is on. Click to pause its uploads (remembered for this account).`
      );
      const p = v.prompt;
      const stale = v.status === "stale";
      show(ask, p || stale);
      if (stale) {
        askTitle.textContent = "You switched X accounts";
        askText.textContent = "This tab still shows the account you had before. Reload it before sharing anything from the new one.";
      } else if (p) {
        askTitle.textContent = `Share ${who}’s feeds?`;
        askText.textContent = `The Home posts you scroll past (Following and For You) upload to a public feed named “${v.handle ? who : "anonymous"}”. Each X account is asked once, and your answer is remembered.`;
        yesBtn.textContent = `Share ${v.handle ? who : "this account"}`;
        noBtn.textContent = p.again ? "Not now" : "Don’t share";
        legacyText.textContent = `Or keep using your existing feed “${p.legacy}”:`;
        legacyBtn.textContent = `Use it for ${who}`;
      }
      show(yesBtn, !stale);
      show(noBtn, !stale);
      show(reloadBtn, stale);
      show(legacyRow, !stale && p?.legacy);
      const newer = app.update();
      show(upd, newer);
      if (newer) {
        updText.textContent = app.updateStarted ? "Click Install (or Update) in the tab that opened, then reload this page to use the new version." : `Version ${newer} of X Feed Share is out. You have ${app.version}.`;
        updBtn.textContent = app.updateStarted ? "Reload page" : "Update now";
      }
      box.style.display = settings.open ? "" : "none";
      if (!settings.open) return;
      const f = a?.feed;
      show(feedInfo, f);
      if (f) {
        feedLabel.textContent = f.label;
        const url = app.publicUrl(f.id);
        if (feedLink.textContent !== url) {
          feedLink.textContent = url;
          feedLink.href = url;
          copyBtn.textContent = "Copy link";
        }
        const verified = f.verified;
        const isPending = !!(a.verify && a.verify.until > Date.now());
        show(verifiedLine, verified);
        if (verified) verifiedLine.textContent = `✓ Verified as @${verified.handle}`;
        show(verifyRow, !isPending);
        verifyBtn.textContent = verified ? "Verify again" : "Verify it’s you";
        verifyHint.textContent = verified ? "" : "Puts a ✓ and your X handle on your feed.";
        show(pending2, isPending);
        if (isPending) pendingText.textContent = a.verify.text;
      }
      for (const [kind] of KIND_ORDER) {
        show(toggles[kind].label, a);
        toggles[kind].input.checked = !!a?.share[kind];
        toggles[kind].stat.textContent = app.sharing(v.uid, kind) ? `${st[kind].shared} shared from this tab · ${st[kind].queued} waiting` : "";
      }
      const live = v.status === "active";
      seenLine2.textContent = v.uid ? `Seen in this tab: ${v.seen.following} Following · ${v.seen.foryou} For You` + (live && st.lastOk ? ` · last upload ${ago(st.lastOk)}` : "") : "";
      noticeLine.textContent = app.notice || "";
      errLine.textContent = app.message || (st.error ? `Upload problem: ${st.error}` : "") + (st.pausedUntil ? ` (retrying after ${new Date(st.pausedUntil).toLocaleTimeString()})` : "");
      show(flushBtn, live);
      show(delBtn, f);
      show(btnRow, live || f);
      othersLine.textContent = v.others.length ? "Other accounts on this browser: " + v.others.map((o) => `${o.handle ? "@" + o.handle : "unnamed"} (${o.state})`).join(" · ") : "";
    }
    return { render };
  }

  // core/update.js
  var UPDATE_KEY = "xfs_update";
  var CHECK_MS = 6 * 36e5;
  var SNOOZE_MS = 24 * 36e5;
  var VERSION_RE = /^\d{1,5}(\.\d{1,5}){0,3}$/;
  var isVersion = (v) => typeof v === "string" && VERSION_RE.test(v);
  function isNewer(a, b) {
    const x = a.split(".").map(Number);
    const y = b.split(".").map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) {
      if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
    }
    return false;
  }
  function createUpdateChecker({ api, store, version, onChange = () => {
  }, now = Date.now }) {
    let state = { checkedAt: 0, latest: null, snoozed: null };
    async function load() {
      const s = await store.get(UPDATE_KEY).catch(() => null);
      if (!s || typeof s !== "object") return;
      state = {
        checkedAt: Number(s.checkedAt) || 0,
        latest: isVersion(s.latest) ? s.latest : null,
        snoozed: s.snoozed && isVersion(s.snoozed.version) ? { version: s.snoozed.version, until: Number(s.snoozed.until) || 0 } : null
      };
    }
    async function check() {
      if (!isVersion(version)) return;
      await load();
      if (now() - state.checkedAt >= CHECK_MS) {
        try {
          const r = await api.version();
          if (isVersion(r?.version)) state.latest = r.version;
          state.checkedAt = now();
          await store.set(UPDATE_KEY, state);
        } catch (_) {
        }
      }
      onChange();
    }
    function available() {
      const v = state.latest;
      if (!v || !isVersion(version) || !isNewer(v, version)) return null;
      if (state.snoozed?.version === v && state.snoozed.until > now()) return null;
      return v;
    }
    async function snooze() {
      state.snoozed = { version: state.latest, until: now() + SNOOZE_MS };
      onChange();
      await store.set(UPDATE_KEY, state).catch(() => {
      });
    }
    return { check, available, snooze };
  }

  // core/uploader.js
  var FLUSH_MS = 3e4;
  var DEBOUNCE_MS = 1500;
  var MIN_GAP_MS = 4e3;
  var MAX_QUEUE = 1e3;
  var SESSION_GAP_MS = 30 * 6e4;
  function createUploader({
    api,
    getFeedId,
    isSharing,
    onChange = () => {
    },
    onAuthLost = () => {
    },
    now = Date.now,
    setTimer = setTimeout
  }) {
    const kinds = {};
    for (const k of KINDS) kinds[k] = { queue: [], seen: /* @__PURE__ */ new Set(), shared: 0, session: 0, pos: 0, lastAdd: 0 };
    const status = { error: null, pausedUntil: 0, backoff: 0, busy: false, lastPush: 0, lastOk: 0 };
    let timer = null;
    let next = 0;
    const pending2 = () => KINDS.some((k) => kinds[k].queue.length && isSharing(k));
    function schedule(delay = DEBOUNCE_MS) {
      if (timer || !pending2()) return;
      const t = now();
      const wait = Math.max(delay, status.lastPush + MIN_GAP_MS - t, status.pausedUntil - t, 0);
      timer = setTimer(() => {
        timer = null;
        return flush();
      }, wait);
    }
    function add(kind, records) {
      const s = kinds[kind];
      if (!s || !isSharing(kind)) return;
      const t = now();
      if (!s.session || t - s.lastAdd > SESSION_GAP_MS) {
        s.session = t;
        s.pos = 0;
      }
      s.lastAdd = t;
      for (const r of records) {
        if (s.seen.has(r.id)) continue;
        s.seen.add(r.id);
        s.queue.push({ session: s.session, pos: s.pos++, tweet: r });
      }
      if (s.queue.length > MAX_QUEUE) s.queue.splice(0, s.queue.length - MAX_QUEUE);
      onChange();
      schedule();
    }
    function clear(kind) {
      const s = kinds[kind];
      s.queue = [];
      s.seen.clear();
      onChange();
    }
    function takeBatch(s) {
      const session = s.queue[0].session;
      let n = 0;
      while (n < s.queue.length && n < MAX_BATCH && s.queue[n].session === session) n++;
      return s.queue.splice(0, n);
    }
    async function flush({ force = false } = {}) {
      if (status.busy) return;
      if (!force && now() < status.pausedUntil) {
        schedule(0);
        return;
      }
      const id = getFeedId();
      const kind = KINDS.map((_, i) => KINDS[(next + i) % KINDS.length]).find((k) => kinds[k].queue.length && isSharing(k));
      if (!id || !kind) return;
      next = (KINDS.indexOf(kind) + 1) % KINDS.length;
      const s = kinds[kind];
      const batch = takeBatch(s);
      status.busy = true;
      status.lastPush = now();
      try {
        await api.push(id, { kind, session: batch[0].session, start: batch[0].pos, tweets: batch.map((b) => b.tweet) });
        s.shared += batch.length;
        Object.assign(status, { error: null, backoff: 0, pausedUntil: 0, lastOk: now() });
      } catch (e) {
        status.error = e.message;
        if (e.status === 400 || e.status === 413) {
        } else if (e.status === 401 || e.status === 404) {
          s.queue.unshift(...batch);
          status.busy = false;
          onAuthLost(e);
          return;
        } else {
          s.queue.unshift(...batch);
          if (e.status === 429) status.pausedUntil = now() + (e.retryAfter || 120) * 1e3;
          else {
            status.backoff = Math.min((status.backoff || 15e3) * 2, 6e5);
            status.pausedUntil = now() + status.backoff;
          }
        }
      } finally {
        status.busy = false;
        onChange();
      }
      schedule(0);
    }
    function stats() {
      const out = { error: status.error, pausedUntil: status.pausedUntil > now() ? status.pausedUntil : 0, lastOk: status.lastOk };
      for (const k of KINDS) out[k] = { shared: kinds[k].shared, queued: kinds[k].queue.length };
      return out;
    }
    return { add, clear, flush, stats };
  }

  // core/app.js
  var SETTINGS_KEY = "xfs_settings_v2";
  var OLD_SETTINGS_KEY = "xfs_settings";
  var RECENT_MAX = 300;
  var VERIFY_RETRY_MS = [2e3, 4e3, 8e3, 15e3];
  var HANDLE_WAIT_MS = 5e3;
  function startApp({ win, request, store, apiOrigin, version = null, updateUrl = null }) {
    const doc = win.document;
    const api = createApi(request);
    const settings = normalizeSettings(null);
    const pageUid = uidFromCookie(doc.cookie);
    const handles = {};
    const tabs = {};
    const uploaders = /* @__PURE__ */ new Map();
    const creating = /* @__PURE__ */ new Map();
    let createFailedAt = 0;
    let uidSince = Date.now();
    let lastUid = pageUid;
    let loaded = false;
    let early = [];
    let panel = null;
    const render = () => panel?.render();
    const current = () => uidFromCookie(doc.cookie);
    const acct = (uid) => uid && settings.accounts[uid] || null;
    const handleOf = (uid) => handles[uid] || acct(uid)?.handle || null;
    const app = {
      api,
      settings,
      message: null,
      notice: null,
      asking: null,
      updateStarted: false,
      ready: false,
      sharing: (uid, k) => {
        const a = acct(uid);
        return !settings.paused && !!a && !a.paused && !!a.feed && !!a.share[k];
      },
      publicUrl: (id) => `${apiOrigin}/f/${id}`
    };
    const tabId = Math.random().toString(36).slice(2);
    const save = () => store.set(SETTINGS_KEY, { ...JSON.parse(JSON.stringify(settings)), by: tabId }).catch(() => {
    });
    const applySettings = (raw) => Object.assign(settings, normalizeSettings(raw), { open: settings.open });
    function tabFor(uid) {
      if (!tabs[uid]) {
        tabs[uid] = { seen: {}, recent: {} };
        for (const k of KINDS) {
          tabs[uid].seen[k] = /* @__PURE__ */ new Set();
          tabs[uid].recent[k] = [];
        }
      }
      return tabs[uid];
    }
    function uploaderFor(uid) {
      if (!uploaders.has(uid)) {
        uploaders.set(uid, createUploader({
          api,
          getFeedId: () => acct(uid)?.feed?.id,
          isSharing: (k) => app.sharing(uid, k),
          onChange: render,
          onAuthLost: () => authLost(uid)
        }));
      }
      return uploaders.get(uid);
    }
    function forget(uid) {
      const t = tabs[uid];
      if (t) for (const k of KINDS) t.recent[k] = [];
      const u = uploaders.get(uid);
      if (u) for (const k of KINDS) u.clear(k);
    }
    function shareRecent(uid) {
      for (const k of KINDS) uploaderFor(uid).add(k, tabFor(uid).recent[k]);
    }
    function reconcile() {
      for (const uid of /* @__PURE__ */ new Set([...Object.keys(tabs), ...uploaders.keys()])) {
        if (settings.paused || acct(uid)?.paused) forget(uid);
        else uploaders.get(uid)?.flush();
      }
    }
    function take(uid, kind, recs) {
      const t = tabFor(uid);
      const fresh = recs.filter((r) => !t.seen[kind].has(r.id));
      for (const r of fresh) t.seen[kind].add(r.id);
      if (!settings.paused && !acct(uid)?.paused) {
        t.recent[kind].push(...fresh);
        if (t.recent[kind].length > RECENT_MAX) t.recent[kind].splice(0, t.recent[kind].length - RECENT_MAX);
      }
      if (wantsFeed(uid)) ensureFeed(uid);
      uploaderFor(uid).add(kind, recs);
    }
    installCapture(win, (kind, json, uid) => {
      if (!uid) return;
      const recs = extractFeed(json);
      if (loaded) {
        take(uid, kind, recs);
        learnHandle();
      } else early.push([uid, kind, recs]);
      render();
    }, (json) => {
      const t = createdTweet(json);
      if (!t) return;
      const text = t.text.toLowerCase();
      for (const [uid, a] of Object.entries(settings.accounts)) {
        if (a.feed && a.verify && Date.now() < a.verify.until && text.includes(a.verify.code)) {
          app.checkVerify(uid, t.id);
          return;
        }
      }
    }, current);
    function learnHandle() {
      const uid = current();
      const h = handleFromDom(doc);
      if (!uid || !h || handles[uid] === h) return;
      const taken = [...Object.entries(settings.accounts).map(([id, a2]) => [id, a2.handle]), ...Object.entries(handles)].some(([id, x]) => id !== uid && sameHandle(x, h));
      if (taken) return;
      handles[uid] = h;
      const a = acct(uid);
      if (a && a.handle !== h) {
        a.handle = h;
        save();
      }
      if (!a && legacyFits(settings.legacy, h)) {
        const label = settings.legacy.feed.label;
        useLegacy(uid);
        app.notice = `Your feed “${label}” now belongs to @${h}. Other X accounts will ask before they share anything.`;
      }
      render();
    }
    function useLegacy(uid) {
      const L = settings.legacy;
      if (!L || acct(uid)) return;
      settings.accounts[uid] = { ...newAccount(handleOf(uid)), paused: false, feed: L.feed, share: L.share, verify: L.verify };
      settings.legacy = null;
      save();
      shareRecent(uid);
    }
    const wantsFeed = (uid) => {
      const a = acct(uid);
      return !settings.paused && !!a && !a.paused && !a.feed && KINDS.some((k) => a.share[k]);
    };
    function ensureFeed(uid, force = false) {
      if (creating.has(uid)) return creating.get(uid);
      if (!wantsFeed(uid) || !force && Date.now() - createFailedAt < 6e4) return null;
      const p = (async () => {
        const saved = await store.get(SETTINGS_KEY).catch(() => null);
        if (normalizeSettings(saved).accounts[uid]?.feed) applySettings(saved);
        if (wantsFeed(uid)) {
          const h = acct(uid).handle;
          const f = await api.createFeed(h ? "@" + h : "anonymous");
          const a = acct(uid);
          if (a) a.feed = { id: f.id, label: f.label };
          app.message = null;
          app.notice = `Sharing is on: ${h ? "@" + h + "’s" : "this account’s"} Following and For You feeds are public as “${f.label}”.`;
          await save();
        }
        shareRecent(uid);
      })().catch((e) => {
        createFailedAt = Date.now();
        app.notice = null;
        app.message = `Could not create your public feed: ${e.message}`;
      }).finally(() => {
        creating.delete(uid);
        render();
      });
      creating.set(uid, p);
      render();
      return p;
    }
    async function authLost(uid) {
      const saved = await store.get(SETTINGS_KEY).catch(() => null);
      const theirs = normalizeSettings(saved).accounts[uid]?.feed?.id;
      if (theirs && theirs !== acct(uid)?.feed?.id) {
        applySettings(saved);
        uploaderFor(uid).flush();
        render();
        return;
      }
      const a = acct(uid);
      if (a) Object.assign(a, { feed: null, paused: true, verify: null });
      forget(uid);
      app.notice = null;
      app.message = `${a?.handle ? "@" + a.handle + "’s" : "This account’s"} shared feed no longer exists, or this browser lost its publish key. Click “${a?.handle ? "@" + a.handle : "Account"}” next to Feeds to start a new one.`;
      save();
      render();
    }
    app.view = () => {
      const uid = current();
      const a = acct(uid);
      const handle = handleOf(uid);
      const waited = Date.now() - uidSince >= HANDLE_WAIT_MS;
      let status;
      if (!uid) status = "signed-out";
      else if (settings.paused) status = "paused-all";
      else if (!a) status = handle || waited && uid === pageUid ? "new" : waited ? "stale" : "loading";
      else if (a.paused) status = a.feed ? "paused" : "off";
      else if (!a.feed) status = "creating";
      else status = KINDS.some((k) => a.share[k]) ? "active" : "none";
      const st = uploaders.get(uid)?.stats() || { error: null, pausedUntil: 0, lastOk: 0, foryou: { shared: 0, queued: 0 }, following: { shared: 0, queued: 0 } };
      const t = uid ? tabFor(uid) : null;
      return {
        uid,
        acct: a,
        handle,
        status,
        stats: st,
        creating: creating.has(uid),
        seen: { foryou: t?.seen.foryou.size || 0, following: t?.seen.following.size || 0 },
        prompt: uid && status !== "stale" && status !== "loading" && (status === "new" || app.asking === uid) ? { again: !!a, legacy: !a && settings.legacy ? settings.legacy.feed.label : null } : null,
        others: Object.entries(settings.accounts).filter(([id]) => id !== uid).map(([, o]) => ({
          handle: o.handle,
          state: o.paused ? o.feed ? "paused" : "not shared" : o.feed ? "sharing" : "not shared"
        }))
      };
    };
    app.decide = async (yes) => {
      const uid = current();
      if (!uid) return;
      app.asking = null;
      app.message = null;
      app.notice = null;
      if (!acct(uid)) settings.accounts[uid] = newAccount(handleOf(uid));
      const a = acct(uid);
      a.paused = !yes;
      if (yes && !KINDS.some((k) => a.share[k])) a.share = { foryou: true, following: true };
      if (!yes) app.notice = `Nothing from ${a.handle ? "@" + a.handle : "this account"} will be shared. Click “${a.handle ? "@" + a.handle : "Account"}” next to Feeds if you change your mind.`;
      await save();
      if (yes) await ensureFeed(uid, true);
      render();
    };
    app.useLegacy = () => {
      const uid = current();
      if (!uid) return;
      app.asking = null;
      app.notice = `Your existing feed is now ${handleOf(uid) ? "@" + handleOf(uid) + "’s" : "this account’s"}.`;
      useLegacy(uid);
      render();
    };
    app.dismissPrompt = () => {
      app.asking = null;
      render();
    };
    app.togglePauseAccount = async () => {
      const uid = current();
      const a = acct(uid);
      if (!uid) return;
      if (!a || a.paused && !a.feed) {
        app.asking = uid;
        render();
        return;
      }
      a.paused = !a.paused;
      app.message = null;
      app.notice = null;
      if (a.paused) forget(uid);
      await save();
      if (!a.paused) {
        if (wantsFeed(uid)) ensureFeed(uid, true);
        uploaderFor(uid).flush();
      }
      render();
    };
    app.togglePauseAll = async () => {
      settings.paused = !settings.paused;
      app.message = null;
      app.notice = null;
      if (settings.paused) for (const uid of /* @__PURE__ */ new Set([...Object.keys(tabs), ...uploaders.keys()])) forget(uid);
      await save();
      if (!settings.paused) {
        const uid = current();
        if (wantsFeed(uid)) ensureFeed(uid, true);
        for (const u of uploaders.values()) u.flush();
      }
      render();
    };
    app.toggleShare = async (kind, on) => {
      const uid = current();
      const a = acct(uid);
      if (!a) return;
      app.message = null;
      app.notice = null;
      a.share[kind] = on;
      if (!on) uploaderFor(uid).clear(kind);
      await save();
      if (on && a.feed) uploaderFor(uid).add(kind, tabFor(uid).recent[kind]);
      if (on && !a.feed && !a.paused) await ensureFeed(uid, true);
      render();
    };
    app.deleteFeed = async () => {
      const uid = current();
      const a = acct(uid);
      if (!a?.feed) return;
      if (!win.confirm("Delete your shared feed? It disappears for everyone, along with everything uploaded to it.")) return;
      try {
        await api.remove(a.feed.id);
        Object.assign(a, { feed: null, paused: true, verify: null });
        forget(uid);
        app.message = null;
        app.notice = `Feed deleted, and ${a.handle ? "@" + a.handle : "this account"} is switched off. Click “${a.handle ? "@" + a.handle : "Account"}” next to Feeds to share it again (you’ll be asked first).`;
        await save();
      } catch (e) {
        app.notice = null;
        app.message = `Delete failed: ${e.message}`;
      }
      render();
    };
    app.startVerify = async () => {
      const a = acct(current());
      if (!a?.feed) return;
      app.message = null;
      app.notice = null;
      try {
        const v = await api.startVerify(a.feed.id);
        a.verify = { code: v.code, text: v.text, until: v.expires_at };
        await save();
        app.openComposer();
      } catch (e) {
        app.notice = null;
        app.message = `Could not start verification: ${e.message}`;
      }
      render();
    };
    app.openComposer = () => {
      const v = acct(current())?.verify;
      if (v) win.open(`https://x.com/intent/post?text=${encodeURIComponent(v.text)}`, "_blank", "noopener");
    };
    app.cancelVerify = async () => {
      const a = acct(current());
      if (a) a.verify = null;
      app.message = null;
      app.notice = null;
      await save();
      render();
    };
    let checking = false;
    app.checkVerify = async (uid, tweetId) => {
      if (!acct(uid)?.feed || !acct(uid).verify || checking) return;
      checking = true;
      app.message = null;
      app.notice = "Checking your post with X…";
      render();
      for (let i = 0; ; i++) {
        try {
          const r = await api.checkVerify(acct(uid).feed.id, tweetId);
          const a = acct(uid);
          if (a?.feed) {
            a.feed.verified = { handle: r.verified_handle, at: r.verified_at };
            a.verify = null;
          }
          app.message = null;
          app.notice = `Verified as @${r.verified_handle}. You can delete the verification post now.`;
          break;
        } catch (e) {
          if ([404, 429, 502].includes(e.status) && i < VERIFY_RETRY_MS.length) {
            await new Promise((res) => setTimeout(res, e.retryAfter ? e.retryAfter * 1e3 : VERIFY_RETRY_MS[i]));
            continue;
          }
          app.notice = null;
          app.message = `Verification failed: ${e.message}`;
          break;
        }
      }
      checking = false;
      await save();
      render();
    };
    app.checkVerifyLink = (text) => {
      const s = String(text).trim();
      const m = s.match(/\/status(?:es)?\/(\d{1,20})/) || s.match(/^(\d{1,20})$/);
      if (!m) {
        app.notice = null;
        app.message = "Paste the link to your post, like https://x.com/you/status/123…";
        render();
        return;
      }
      app.checkVerify(current(), m[1]);
    };
    app.flushNow = () => uploaders.get(current())?.flush({ force: true });
    app.setOpen = (open) => {
      settings.open = open;
      save();
      render();
    };
    app.updates = updateUrl ? createUpdateChecker({ api, store, version, onChange: render }) : null;
    app.update = () => app.updates?.available() || null;
    app.version = version;
    app.startUpdate = () => {
      app.updateStarted = true;
      win.open(updateUrl, "_blank", "noopener");
      render();
    };
    app.snoozeUpdate = () => {
      app.updateStarted = false;
      app.updates?.snooze();
    };
    app.reload = () => win.location.reload();
    async function load() {
      let raw = await store.get(SETTINGS_KEY).catch(() => null);
      if (!raw) {
        const old = await store.get(OLD_SETTINGS_KEY).catch(() => null);
        raw = migrateSettings(old);
        Object.assign(settings, raw);
        if (old) await save();
      } else Object.assign(settings, normalizeSettings(raw));
    }
    load().catch(() => {
    }).finally(() => {
      loaded = true;
      app.ready = true;
      for (const [uid, kind, recs] of early) take(uid, kind, recs);
      early = [];
      learnHandle();
      render();
      app.updates?.check();
    });
    store.watch?.(SETTINGS_KEY, (v) => {
      if (!loaded || v?.by === tabId) return;
      applySettings(v);
      reconcile();
      render();
    });
    doc.addEventListener("visibilitychange", () => {
      if (doc.visibilityState === "hidden") {
        for (const u of uploaders.values()) u.flush();
        return;
      }
      if (!loaded) return;
      store.get(SETTINGS_KEY).then((s) => {
        if (s) {
          applySettings(s);
          reconcile();
        }
        render();
      }).catch(() => {
      });
    });
    setInterval(() => {
      const uid = current();
      if (uid !== lastUid) {
        lastUid = uid;
        uidSince = Date.now();
        app.asking = null;
        render();
      }
      if (loaded) learnHandle();
      if (!handleOf(uid) && Date.now() - uidSince < HANDLE_WAIT_MS + 1500) render();
    }, 1e3);
    setInterval(() => {
      for (const u of uploaders.values()) u.flush();
    }, FLUSH_MS);
    setInterval(() => app.updates?.check(), 36e5);
    const mount = () => {
      panel = mountPanel(doc, win, app);
      render();
    };
    if (doc.body) mount();
    else doc.addEventListener("DOMContentLoaded", mount);
    return app;
  }

  // extension/main.js
  var pending = /* @__PURE__ */ new Map();
  var watchers = /* @__PURE__ */ new Map();
  var seq = 0;
  window.addEventListener("message", (e) => {
    if (e.source !== window) return;
    if (e.data?.__xfs === "chg") {
      for (const cb of watchers.get(e.data.key) || []) cb(e.data.value);
      return;
    }
    if (e.data?.__xfs !== "res") return;
    const p = pending.get(e.data.id);
    if (!p) return;
    pending.delete(e.data.id);
    if (e.data.error) p.reject(new Error(e.data.error));
    else p.resolve(e.data.result);
  });
  function call(msg) {
    return new Promise((resolve, reject) => {
      const id = `${++seq}:${Math.random().toString(36).slice(2)}`;
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error("extension did not answer; refresh this tab"));
      }, 25e3);
      pending.set(id, {
        resolve: (v) => {
          clearTimeout(timer);
          resolve(v);
        },
        reject: (e) => {
          clearTimeout(timer);
          reject(e);
        }
      });
      window.postMessage({ __xfs: "req", id, msg }, location.origin);
    });
  }
  startApp({
    win: window,
    apiOrigin: "https://gestaltschaft.com/feeds",
    request: (method, path, body, auth) => call({ op: "request", method, path, body, auth }),
    store: {
      get: (key) => call({ op: "get", key }),
      set: (key, value) => call({ op: "set", key, value }),
      watch: (key, cb) => {
        if (!watchers.has(key)) watchers.set(key, []);
        watchers.get(key).push(cb);
      }
    }
  });
})();
